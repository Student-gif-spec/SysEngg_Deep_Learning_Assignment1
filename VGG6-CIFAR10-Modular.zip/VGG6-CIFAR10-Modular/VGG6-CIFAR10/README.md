CS6886W - Systems Engineering for Deep Learning
Assignment 1
This repository VGG6-CIFAR10-Modular.zip contains a modular Python implementation of VGG6 for CIFAR-10 classification and the experiments required for Assignment 1.

Project Package

1. Installation
Clone the repository: git clone <https://github.com/Student-gif-spec/SysEngg_Deep_Learning_Assignment1>
Enter the repository:

The assignment implementation is provided as the modular project:VGG6-CIFAR10-Modular.zip
After extracting the ZIP file, the project directory is:VGG6-CIFAR10/

In google colab use the following code to extract the zip file and go to the directory.
Extract the Submitted ZIP Package
unzip VGG6-CIFAR10-Modular.zip

Then enter the project directory:
cd VGG6-CIFAR10

All commands in this README must be executed from inside the extracted VGG6-CIFAR10 directory.

Install dependencies:

pip install -r requirements.txt

CIFAR-10 does not need to be downloaded manually. torchvision downloads the dataset automatically when required.

The project evaluates various activation functions, various optimisers performance based Learning rate,Batch size and Number of training epochs

List of Activation functions used:
ReLU
Sigmoid
Tanh
SiLU
GELU
List of Optimizers used:
SGD
Nesterov-SGD
Adam
Adagrad
RMSprop
Nadam

Weights & Biases (W&B) is used for experiment tracking, hyperparameter sweeps, and experiment visualization.

2. Repository Structure
VGG6-CIFAR10-Modular/VGG6-CIFAR10/

├── README.md
├── requirements.txt
├── .gitignore
├── configs/ 
│ ├── baseline.yaml
│ ├── activation_sweep.yaml
│ ├── optimizer_sweep.yaml
│ ├── combined_sweep.yaml
│ └── best.yaml
├── src/
│ ├── init.py
│ ├── data.py
│ ├── model.py
│ ├── train.py
│ ├── evaluate.py
│ └── plot_history.py
├── scripts/
│ ├── init.py
│ ├── run_sweep.py
│ ├── show_best_run.py
│ └── export_sweep_plots.py
├── tests/
│ └── test_model.py
├── checkpoints/
│ └── best_model.pt
└── outputs/

3. Code Organization
The implementation is modular and separates training from evaluation.

src/data.py
Contains:
CIFAR-10 loading
Data augmentation
Normalization
Train/validation split
DataLoader creation
Random-seed handling for DataLoader workers

src/model.py
Contains:
VGG6 architecture
Activation-function selection
ReLU
Sigmoid
Tanh
SiLU
GELU

src/train.py
Contains:
Training loop
Mini-batch processing
Loss calculation
Backpropagation
Optimizer selection
Validation after every epoch
Best-checkpoint selection
W&B metric logging
Training-history generation

src/evaluate.py
Contains independent evaluation of saved checkpoints.
The evaluator can calculate:
Validation loss
Validation top-1 accuracy
Test loss
Test top-1 accuracy

src/plot_history.py
Generates:
Training accuracy
Training loss
Validation accuracy
Validation loss
scripts/run_sweep.py
Entry point used by W&B sweep agents.

scripts/show_best_run.py
Finds the completed W&B run with the highest validation accuracy.

scripts/export_sweep_plots.py
Exports sweep-derived experiment results and plots.

4. Environment
The project requires Python and PyTorch.

CUDA is used automatically when a compatible GPU is available.

Check Python version:

python --version
Check PyTorch and CUDA:

python -c "import torch;
print('PyTorch:', torch.__version__);
print('CUDA:', torch.version.cuda); print('CUDA available:', torch.cuda.is_available())"
The exact package versions used for the submitted experiment are recorded in requirements.txt.

5. Reproducibility
The experiments use a fixed random seed:

seed = 42
The seed is applied to:

Python random
NumPy
PyTorch CPU
PyTorch CUDA
CIFAR-10 train/validation split
DataLoader random-number generation
The training implementation additionally uses deterministic cuDNN settings:
torch.backends.cudnn.deterministic = True
torch.backends.cudnn.benchmark = False

The final selected experiment parameters are stored in:
configs/best.yaml
This allows the submitted model configuration to be reproduced without changing the Python source code.

6. Dataset Preparation
The CIFAR-10 training data is divided into:
Training   : 45,000 images
Validation :  5,000 images

The official CIFAR-10 test set contains:
Test       : 10,000 images

Training augmentation:
RandomCrop(32, padding=4)
RandomHorizontalFlip()
ToTensor()
CIFAR-10 normalization
Cutout(length=16)

Validation and test preprocessing:
ToTensor()
CIFAR-10 normalization

7. Verify the Repository
Before starting training, verify Python syntax:

python -m compileall -q src scripts tests
Run automated tests:

python -m pytest -q
Check the training command:

python -m src.train --help

8. Baseline Configuration
The baseline configuration is stored in:
configs/baseline.yaml

Baseline parameters:
Model           : VGG6
Activation      : ReLU
Optimizer       : Adam
Learning rate   : 0.001
Batch size      : 64
Epochs          : 20
Weight decay    : 0.0005
Seed            : 42

9. Run the Baseline
Execute:
python -m src.train --config configs/baseline.yaml --no-wandb

The best validation checkpoint is saved as:
checkpoints/baseline_best.pt

Training history is stored as:
outputs/baseline_history.csv

10. Evaluate the Baseline
Execute the independent evaluator:
python -m src.evaluate --config configs/baseline.yaml --checkpoint checkpoints/baseline_best.pt --split both
Reported baseline results:

Best validation accuracy : 78.26%
Test top-1 accuracy      : 79.04%

11. Generate Baseline Curves
Execute:
python -m src.plot_history --history outputs/baseline_history.csv --output-dir outputs/baseline_plots
Generated files:
training_accuracy.png
training_loss.png
validation_accuracy.png
validation_loss.png

12. W&B Authentication
W&B is required only when reproducing the sweep experiments.
Authenticate using:
wandb login
Provide WB API key when it is prompted.

13. Activation Sweep
The controlled activation experiment evaluates:
ReLU
Sigmoid
Tanh
SiLU
GELU
Create the activation sweep:
wandb sweep configs/activation_sweep.yaml

W&B prints a sweep identifier similar to:
ENTITY/PROJECT/SWEEP_ID
Run all five activation experiments with the generated sweep identifier

wandb agent --count 5 ENTITY/PROJECT/SWEEP_ID
Replace ENTITY/PROJECT/SWEEP_ID with the value returned by W&B.

14. Optimizer Sweep
The controlled optimizer experiment evaluates:
SGD
Nesterov-SGD
Adam
Adagrad
RMSprop
Nadam
Create the optimizer sweep:

wandb sweep configs/optimizer_sweep.yaml
Run all six optimizer experiments using the newly generated sweep ID:

wandb agent --count 6 ENTITY/PROJECT/SWEEP_ID
15. Combined Hyperparameter Sweep
The combined W&B experiment explores:

Activation function
Optimizer
Learning rate
Batch size
Number of epochs
Create the sweep:

wandb sweep configs/combined_sweep.yaml
Run the sampled configurations:

wandb agent --count 15 ENTITY/PROJECT/SWEEP_ID
Replace ENTITY/PROJECT/SWEEP_ID with the combined sweep ID returned by W&B.

16. Identify the Best W&B Run
After completing the combined sweep:
python scripts/show_best_run.py --sweep ENTITY/PROJECT/SWEEP_ID

The final configuration selected from the reported combined sweep was:

Activation      : GELU
Optimizer       : RMSprop
Learning rate   : 0.0001
Batch size      : 32
Epochs          : 20
Weight decay    : 0.0005
Seed            : 42
The selected configuration is stored in:
configs/best.yaml

17. Final Configuration
configs/best.yaml contains:
activation: gelu
optimizer: rmsprop
learning_rate: 0.0001
batch_size: 32
epochs: 20
weight_decay: 0.0005
seed: 42
workers: 2
data_dir: data
use_wandb: true
wandb_project: vgg6-cifar10
checkpoint_path: checkpoints/best_model.pt
history_path: outputs/best_history.csv

18. Reproduce the Final Model
To retrain the selected configuration:
python -m src.train --config configs/best.yaml

The best validation checkpoint is saved as:
checkpoints/best_model.pt

The epoch-wise training history is saved as:
outputs/best_history.csv

19. Evaluate the Submitted Model
A trained checkpoint is included at:
checkpoints/best_model.pt

Run:
python -m src.evaluate --config configs/best.yaml --checkpoint checkpoints/best_model.pt --split both

The submitted final checkpoint produced:
Validation accuracy : 78.62%
Test top-1 accuracy : 77.45%

20. Generate Final Learning Curves
Run:
python -m src.plot_history --history outputs/best_history.csv --output-dir outputs/best_plots

Generated figures:
training_accuracy.png
training_loss.png
validation_accuracy.png
validation_loss.png

21. W&B Logged Metrics
The training pipeline logs the following metrics to W&B:
train/loss
train/accuracy
validation/loss
validation/accuracy
These metrics are used for assignment plots and convergence analysis.

22. Export Sweep Plots
Run:
python scripts/export_sweep_plots.py --sweep ENTITY/PROJECT/SWEEP_ID --output-dir outputs/sweep_plots

The experiment analysis includes:
Parallel-coordinate plot
Validation accuracy vs. step
Training accuracy
Training loss
Validation accuracy
Validation loss
The assignment report contains the W&B experiment visualizations.



