VGG6 on CIFAR-10
CS6886W - Systems Engineering for Deep Learning
Assignment 1
This repository contains the model training and experimental evaluation of a VGG6 convolutional neural network on the CIFAR-10 dataset.

The assignment evaluates various activation functions, optimizers based on Learning rate, Batch size and Number of training epochs
Activation functions:
ReLU
Sigmoid
Tanh
SiLU
GELU

Optimizers:
SGD
Nesterov-SGD
Adam
Adagrad
RMSprop
Nadam

Weights & Biases (W&B) is used for experiment tracking, hyperparameter sweeps, and visualization.

1. Submission Components
The submission contains two main components:
VGG6_CIFAR10_Assignment1.ipynb
and
VGG6-CIFAR10-Modular.zip

The notebook is the Google Colab execution interface.
The ZIP file contains the actual modular Python project.

After extraction:

VGG6-CIFAR10-Modular.zip
          |
          v
    VGG6-CIFAR10/
          |
          +-- README.md
          +-- requirements.txt
          +-- configs/
          +-- src/
          +-- scripts/
          +-- tests/
          +-- checkpoints/
          +-- outputs/
Note:
The assignment implementation is not contained in a single notebook or single Python file.

The Colab notebook is used only as an execution and experiment interface.

The actual implementation is separated into modular Python files for:

Dataset preparation
VGG6 model definition
Training
Evaluation
Plot generation
W&B sweep execution
Experiment-result analysis
Automated testing

2. Google Colab Notebook Interface : VGG6_CIFAR10_Assignment1_Colab.ipynb
The notebook provides the execution workflow for the assignment.

The notebook performs the following operations:

Mount Google Drive.
Locate the submitted modular ZIP file.
Extract the modular Python project.
Identify and enter the project root.
Install dependencies.
Verify CUDA/GPU availability.
Compile Python modules for syntax validation.
Verify project imports.
Execute automated tests.
Run the baseline experiment.
Independently evaluate the baseline checkpoint.
Generate baseline learning curves.
Authenticate with W&B.
Execute the activation-function sweep.
Execute the optimizer sweep.
Execute the combined hyperparameter sweep.
Extract experiment results from W&B.
Generate the assignment plots.
Identify the best experiment configuration.
Write the selected configuration to best.yaml.
Execute the final reproducibility run.
Independently evaluate the final saved checkpoint.

Therefore Colab notebook is the experiment execution interface,

while:
src/model.py
contains the VGG6 implementation,

src/data.py
contains the CIFAR-10 data pipeline,

src/train.py
contains the training implementation,

and:

src/evaluate.py
contains the independent evaluation implementation.

3. Repository Structure
After extracting the ZIP, the project structure is:

VGG6-CIFAR10/
|
+-- README.md
+-- requirements.txt
+-- .gitignore
|
+-- configs/
|   +-- baseline.yaml
|   +-- activation_sweep.yaml
|   +-- optimizer_sweep.yaml
|   +-- combined_sweep.yaml
|   +-- best.yaml
|
+-- src/
|   +-- __init__.py
|   +-- data.py
|   +-- model.py
|   +-- train.py
|   +-- evaluate.py
|   +-- plot_history.py
|
+-- scripts/
|   +-- __init__.py
|   +-- run_sweep.py
|   +-- show_best_run.py
|   +-- export_sweep_plots.py
|
+-- tests/
|   +-- test_model.py
|
+-- checkpoints/
|   +-- best_model.pt
|
+-- outputs/

4. Module Responsibilities
src/data.py

Responsible for:
CIFAR-10 downloading
Training augmentation
Normalization
Train/validation split
DataLoader creation
DataLoader seed handling

src/model.py
Contains:
VGG6 architecture
ReLU
Sigmoid
Tanh
SiLU
GELU

src/train.py
Responsible for:
Reproducibility setup
VGG6 training
Optimizer selection
Epoch-wise training loop
Mini-batch processing
Cross-entropy loss
Backpropagation
Validation after each epoch
W&B logging
Best-checkpoint selection
CSV history generation
Final test evaluation

src/evaluate.py
Provides independent checkpoint evaluation.
It reports:
Validation loss
Validation top-1 accuracy
Test loss
Test top-1 accuracy
src/plot_history.py
Generates:
Training accuracy
Training loss
Validation accuracy
Validation loss

scripts/run_sweep.py
W&B sweep execution entry point.

scripts/show_best_run.py
Retrieves the completed W&B run with the highest validation accuracy.

scripts/export_sweep_plots.py
Exports experiment results and sweep-derived visualizations.

5. Running Through Google Colab
Step 1 - Upload Required Files
Upload the following to Google Drive:

VGG6_CIFAR10_Assignment1_Colab.ipynb
and
VGG6-CIFAR10-Modular.zip

Step 2 - Open the Notebook
VGG6_CIFAR10_Assignment1_Colab.ipynb in Google Colab.

Step 3 - Select the Runtime
Where a GPU runtime is available, select a CUDA-enabled runtime.
The code automatically checks:
torch.cuda.is_available()
and uses CUDA when available.

Step 4 - Mount Google Drive
The notebook mounts Google Drive to access:VGG6-CIFAR10-Modular.zip

Step 5 - Extract the Project
The notebook extracts the ZIP into the Colab workspace.

The project root used in the submitted workflow is:
/content/vgg6_workspace/VGG6-CIFAR10

Step 6 - Enter the Project Root
All subsequent Python commands are executed from:
/content/vgg6_workspace/VGG6-CIFAR10

6. Install Dependencies
Run:
pip install -r requirements.txt
The project uses the following primary packages:
torch
torchvision
numpy
pandas
matplotlib
PyYAML
wandb
pytest

7. Environment Verification
Check Python:
python --version
Check PyTorch and CUDA:
python -c "import torch; print('PyTorch:', torch.__version__); print('CUDA:', torch.version.cuda); print('CUDA available:', torch.cuda.is_available())"
If CUDA is available, the model is automatically executed on the GPU.

8. Reproducibility
All reported experiments use the random seed:
seed = 42
The seed is applied to:
Python random
NumPy
PyTorch CPU
PyTorch CUDA
CIFAR-10 train/validation splitting
DataLoader random-number generation

The training implementation also configures:
torch.backends.cudnn.deterministic = True
torch.backends.cudnn.benchmark = False

The final model configuration is stored separately in:
configs/best.yaml
This allows the final model to be rerun without changing Python source code.

9. Dataset Preparation
CIFAR-10 is downloaded automatically using torchvision.

The original CIFAR-10 training set is divided into:

Training   : 45,000 images
Validation :  5,000 images
The official CIFAR-10 test set contains:

Test       : 10,000 images
Training preprocessing and augmentation include:

RandomCrop(32, padding=4)
RandomHorizontalFlip()
ToTensor()
CIFAR-10 normalization
Cutout(length=16)
Validation and test images use:

ToTensor()
CIFAR-10 normalization

10. Verify the Project Before Training
Compile all source modules:

python -m compileall -q src scripts tests
Run automated tests:

python -m pytest -q
Verify the training command:

python -m src.train --help
These checks should be completed before starting a long training run.

11. Baseline Configuration
The baseline configuration is stored in:
configs/baseline.yaml

Baseline parameters:
Model           : VGG6
Activation      : ReLU
Optimizer       : Adam
Learning rate   : 0.001
Batch size      : 64
Epochs          : 20
Weight decay    : 0.0005
Seed            : 42

12. Train the Baseline
Run:
python -m src.train --config configs/baseline.yaml --no-wandb
Outputs:
checkpoints/baseline_best.pt
and:
outputs/baseline_history.csv

13. Evaluate the Baseline
Run:
python -m src.evaluate --config configs/baseline.yaml --checkpoint checkpoints/baseline_best.pt --split both
Reported baseline results:
Best validation accuracy : 78.26%
Test top-1 accuracy      : 79.04%

14. Generate Baseline Curves
Run:
python -m src.plot_history --history outputs/baseline_history.csv --output-dir outputs/baseline_plots
Generated files:

training_accuracy.png
training_loss.png
validation_accuracy.png
validation_loss.png

15. W&B Authentication
W&B is required for reproducing the hyperparameter sweeps.
Authenticate using:
wandb login
W&B API key .

16. Activation-Function Experiment
The activation experiment evaluates:
ReLU
Sigmoid
Tanh
SiLU
GELU
Create the sweep:
wandb sweep configs/activation_sweep.yaml
W&B returns:
ENTITY/PROJECT/SWEEP_ID
Run the five activation experiments 
wandb agent --count 5 ENTITY/PROJECT/SWEEP_ID
Replace ENTITY/PROJECT/SWEEP_ID with the actual W&B sweep identifier.

17. Optimizer Experiment
The optimizer experiment evaluates:
SGD
Nesterov-SGD
Adam
Adagrad
RMSprop
Nadam
Create the sweep:

wandb sweep configs/optimizer_sweep.yaml
Run the six experiments:

wandb agent --count 6 ENTITY/PROJECT/SWEEP_ID
Use the new optimizer sweep ID returned by W&B.

18. Combined Hyperparameter Sweep
The broader combined W&B experiment explores:

Activation
Optimizer
Learning rate
Batch size
Number of epochs
Create the sweep:

wandb sweep configs/combined_sweep.yaml
Execute sampled configurations:

wandb agent --count 15 ENTITY/PROJECT/SWEEP_ID
The combined sweep is used for:

Configuration interaction analysis
W&B visualizations
Final configuration selection

19. Identify the Best W&B Configuration
Run:

python scripts/show_best_run.py --sweep ENTITY/PROJECT/SWEEP_ID
The reported sweep selected:

Activation      : GELU
Optimizer       : RMSprop
Learning rate   : 0.0001
Batch size      : 32
Epochs          : 20
Weight decay    : 0.0005
Seed            : 42
The corresponding configuration is stored in:
configs/best.yaml

20. Final Configuration
The final configuration is:
activation: gelu
optimizer: rmsprop
learning_rate: 0.0001
batch_size: 32
epochs: 20
weight_decay: 0.0005
seed: 42
workers: 2
data_dir: data
use_wandb: true
wandb_project: vgg6-cifar10
checkpoint_path: checkpoints/best_model.pt
history_path: outputs/best_history.csv

21. Reproduce the Final Model
Run:
python -m src.train --config configs/best.yaml
Outputs:
checkpoints/best_model.pt
and:
outputs/best_history.csv

22. Evaluate the Final Model
A trained final checkpoint is included in:
checkpoints/best_model.pt
The final model can therefore be evaluated without retraining:
python -m src.evaluate --config configs/best.yaml --checkpoint checkpoints/best_model.pt --split both

Reported submitted-checkpoint results:
Validation accuracy : 78.62%
Test top-1 accuracy : 77.45%

23. Generate Final Learning Curves
Run:
python -m src.plot_history --history outputs/best_history.csv --output-dir outputs/best_plots

This generates:
training_accuracy.png
training_loss.png
validation_accuracy.png
validation_loss.png

24. W&B Logged Metrics
The training code logs the following metrics:

epoch
train/loss
train/accuracy
validation/loss
validation/accuracy

Final run summaries include:
best_validation_accuracy
final_test_accuracy
These metrics are used to generate the assignment visualizations.

25. W&B Assignment Plots

The assignment analysis contains:
Parallel-coordinate plot
Validation accuracy vs. step scatter plot
Training loss
Training accuracy
Validation loss
Validation accuracy

Sweep-derived local plots can be exported using:
python scripts/export_sweep_plots.py --sweep ENTITY/PROJECT/SWEEP_ID --output-dir outputs/sweep_plots
Native W&B panels are used in the assignment report where W&B-generated visualizations are explicitly required.

