import torch
from src.model import VGG6


def test_forward_shape():
    model = VGG6("relu")
    assert model(torch.randn(2, 3, 32, 32)).shape == (2, 10)


def test_all_activations_construct():
    for activation in ["relu", "sigmoid", "tanh", "silu", "gelu"]:
        VGG6(activation)
