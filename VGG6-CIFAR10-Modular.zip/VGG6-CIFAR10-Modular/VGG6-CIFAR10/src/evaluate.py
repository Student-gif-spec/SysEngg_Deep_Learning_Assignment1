# argparse provides command-line arguments.
import argparse

# YAML loads the experimental configuration.
import yaml

# Import PyTorch.
import torch

# Neural-network loss functions.
import torch.nn as nn

# Import CIFAR-10 DataLoader construction.
from .data import make_loaders

# Import VGG6 model.
from .model import VGG6


def evaluate_loader(
    model,
    loader,
    criterion,
    device
):
    """
    Evaluate a trained model on one DataLoader.
    """

    # Switch BatchNorm and other relevant layers to evaluation mode.
    model.eval()

    # Initialize accumulated statistics.
    loss_sum = 0
    correct = 0
    count = 0

    # Disable gradient computation because evaluation
    # does not perform backpropagation.
    with torch.no_grad():

        # Iterate through evaluation batches.
        for images, labels in loader:

            # Move input images to CPU/GPU.
            images = images.to(
                device,
                non_blocking=True
            )

            # Move target labels to CPU/GPU.
            labels = labels.to(
                device,
                non_blocking=True
            )

            # Perform forward propagation.
            logits = model(images)

            # Calculate classification loss.
            loss = criterion(
                logits,
                labels
            )

            # Accumulate batch loss.
            loss_sum += (
                loss.item()
                * labels.size(0)
            )

            # Count correctly classified samples.
            correct += (
                logits.argmax(1)
                == labels
            ).sum().item()

            # Count processed samples.
            count += labels.size(0)

    # Return average loss and top-1 accuracy.
    return {
        "loss":
            loss_sum / count,

        "accuracy":
            100.0 * correct / count
    }


def evaluate_checkpoint(
    config_path,
    checkpoint_path,
    split="both"
):
    """
    Load a saved checkpoint and independently evaluate
    validation and/or test performance.
    """

    # Read the YAML configuration.
    with open(
        config_path
    ) as file:

        cfg = yaml.safe_load(
            file
        )

    # Select GPU when available.
    device = torch.device(
        "cuda"
        if torch.cuda.is_available()
        else "cpu"
    )

    # Recreate the same validation and test data.
    _, _, validation_loader, test_loader = make_loaders(
        cfg.get(
            "data_dir",
            "data"
        ),

        int(
            cfg.get(
                "batch_size",
                64
            )
        ),

        int(
            cfg.get(
                "seed",
                42
            )
        ),

        int(
            cfg.get(
                "workers",
                2
            )
        )
    )

    # Recreate VGG6 using the recorded activation.
    model = VGG6(
        cfg.get(
            "activation",
            "relu"
        )
    ).to(device)

    # Load the saved checkpoint.
    checkpoint = torch.load(
        checkpoint_path,
        map_location=device
    )

    # Support checkpoint dictionaries containing model_state.
    model.load_state_dict(
        checkpoint["model_state"]
        if "model_state" in checkpoint
        else checkpoint
    )

    # Use cross-entropy loss for CIFAR-10 classification.
    criterion = nn.CrossEntropyLoss()

    # Store requested evaluation results.
    results = {}

    # Evaluate validation data when requested.
    if split in (
        "validation",
        "both"
    ):

        results["validation"] = evaluate_loader(
            model,
            validation_loader,
            criterion,
            device
        )

    # Evaluate official test data when requested.
    if split in (
        "test",
        "both"
    ):

        results["test"] = evaluate_loader(
            model,
            test_loader,
            criterion,
            device
        )

    # Print results for the command-line user.
    print(results)

    return results


# Execute CLI only when this module is run directly.
if __name__ == "__main__":

    # Create command-line argument parser.
    parser = argparse.ArgumentParser()

    # Configuration YAML is mandatory.
    parser.add_argument(
        "--config",
        required=True
    )

    # Checkpoint file is mandatory.
    parser.add_argument(
        "--checkpoint",
        required=True
    )

    # Allow validation, test, or both datasets.
    parser.add_argument(
        "--split",
        choices=[
            "validation",
            "test",
            "both"
        ],
        default="both"
    )

    # Parse command-line arguments.
    args = parser.parse_args()

    # Run independent evaluation.
    evaluate_checkpoint(
        args.config,
        args.checkpoint,
        args.split
    )