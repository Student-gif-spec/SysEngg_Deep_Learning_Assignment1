"""
Training module for the VGG6 CIFAR-10 assignment.

Responsibilities:
1. Set random seeds for reproducibility.
2. Create CIFAR-10 DataLoaders.
3. Build the VGG6 model.
4. Construct the selected optimizer.
5. Train the model epoch by epoch.
6. Evaluate the model on the validation set after every epoch.
7. Log training/validation metrics to Weights & Biases.
8. Save the checkpoint with the highest validation accuracy.
9. Save epoch-wise training history to CSV.
10. Evaluate the selected checkpoint on the CIFAR-10 test set.

Training and independent evaluation are separated:
- Training logic is implemented in this file.
- Standalone checkpoint evaluation is implemented in src/evaluate.py.
"""

# argparse is used to accept command-line arguments.
import argparse

# random is used to seed Python's random-number generator.
import random

# Path provides platform-independent file-path handling.
from pathlib import Path

# NumPy is used for reproducibility.
import numpy as np

# pandas is used to save epoch-wise results to CSV.
import pandas as pd

# PyTorch provides tensors, GPU support, and optimization.
import torch

# torch.nn provides the CrossEntropyLoss used for classification.
import torch.nn as nn

# PyYAML is used to read experiment configuration files.
import yaml

# Import CIFAR-10 DataLoader creation from the data module.
from .data import make_loaders

# Import the common evaluation function from the evaluation module.
from .evaluate import evaluate_loader

# Import the VGG6 model from the model module.
from .model import VGG6


# ============================================================
# Reproducibility
# ============================================================

def set_seed(seed):
    """
    Configure random-number generators for reproducible runs.

    Args:
        seed (int):
            Seed used by Python, NumPy, CPU PyTorch,
            and CUDA PyTorch operations.
    """

    # Seed Python's built-in random-number generator.
    random.seed(seed)

    # Seed NumPy's random-number generator.
    np.random.seed(seed)

    # Seed PyTorch operations executed on the CPU.
    torch.manual_seed(seed)

    # Seed PyTorch operations on all available CUDA devices.
    torch.cuda.manual_seed_all(seed)

    # Request deterministic CUDA convolution behavior.
    torch.backends.cudnn.deterministic = True

    # Disable cuDNN benchmarking because selecting different
    # algorithms according to timing can reduce reproducibility.
    torch.backends.cudnn.benchmark = False


# ============================================================
# Optimizer Factory
# ============================================================

def make_optimizer(
    name,
    parameters,
    lr,
    weight_decay,
    momentum=0.9
):
    """
    Create the optimizer requested by the YAML configuration.

    Supported optimizers:
    - SGD
    - Nesterov-SGD
    - Adam
    - Adagrad
    - RMSprop
    - Nadam

    Args:
        name:
            Optimizer name.

        parameters:
            Model parameters to optimize.

        lr:
            Learning rate.

        weight_decay:
            Weight-decay regularization strength.

        momentum:
            Momentum used by SGD, Nesterov-SGD, and RMSprop.

    Returns:
        Configured PyTorch optimizer.
    """

    # Convert the optimizer name to lowercase so that
    # configuration matching is case-insensitive.
    name = name.lower()

    # --------------------------------------------------------
    # SGD
    # --------------------------------------------------------

    if name == "sgd":

        return torch.optim.SGD(
            parameters,
            lr=lr,
            momentum=momentum,
            weight_decay=weight_decay
        )

    # --------------------------------------------------------
    # Nesterov-SGD
    # --------------------------------------------------------

    if name in (
        "nesterov",
        "nesterov_sgd"
    ):

        return torch.optim.SGD(
            parameters,
            lr=lr,
            momentum=momentum,
            nesterov=True,
            weight_decay=weight_decay
        )

    # --------------------------------------------------------
    # Adam
    # --------------------------------------------------------

    if name == "adam":

        return torch.optim.Adam(
            parameters,
            lr=lr,
            weight_decay=weight_decay
        )

    # --------------------------------------------------------
    # Adagrad
    # --------------------------------------------------------

    if name == "adagrad":

        return torch.optim.Adagrad(
            parameters,
            lr=lr,
            weight_decay=weight_decay
        )

    # --------------------------------------------------------
    # RMSprop
    # --------------------------------------------------------

    if name == "rmsprop":

        return torch.optim.RMSprop(
            parameters,
            lr=lr,
            momentum=momentum,
            weight_decay=weight_decay
        )

    # --------------------------------------------------------
    # Nadam
    # --------------------------------------------------------

    if name == "nadam":

        return torch.optim.NAdam(
            parameters,
            lr=lr,
            weight_decay=weight_decay
        )

    # Stop execution if the YAML contains an unsupported name.
    raise ValueError(
        f"Unsupported optimizer: {name}"
    )


# ============================================================
# Main Training Function
# ============================================================

def train(
    cfg,
    finish_wandb=True
):
    """
    Train VGG6 using an experiment configuration.

    The function performs:

    1. Reproducibility initialization.
    2. DataLoader creation.
    3. Model creation.
    4. Optimizer creation.
    5. Epoch-wise training.
    6. Epoch-wise validation.
    7. W&B logging when enabled.
    8. Best-validation checkpoint selection.
    9. History CSV creation.
    10. Final test evaluation.

    Args:
        cfg:
            Dictionary containing experiment configuration.

        finish_wandb:
            Controls whether this function closes the active
            W&B run. Sweep execution keeps this False because
            scripts/run_sweep.py owns the W&B context.

    Returns:
        history:
            List containing metrics for every training epoch.
    """

    # Copy the configuration to avoid modifying the caller's
    # original dictionary.
    cfg = dict(cfg)

    # --------------------------------------------------------
    # Read reproducibility configuration
    # --------------------------------------------------------

    # Obtain the seed from YAML.
    # Use 42 only if the field is missing.
    seed = int(
        cfg.get(
            "seed",
            42
        )
    )

    # Apply all reproducibility settings.
    set_seed(seed)

    # --------------------------------------------------------
    # Select compute device
    # --------------------------------------------------------

    # Use CUDA GPU if available; otherwise use CPU.
    device = torch.device(
        "cuda"
        if torch.cuda.is_available()
        else "cpu"
    )

    # Print the selected device for reproducibility evidence.
    print(
        "Device:",
        device
    )

    # --------------------------------------------------------
    # Create CIFAR-10 DataLoaders
    # --------------------------------------------------------

    (
        train_loader,
        train_eval_loader,
        val_loader,
        test_loader
    ) = make_loaders(

        # Directory used to download/store CIFAR-10.
        cfg.get(
            "data_dir",
            "data"
        ),

        # Mini-batch size specified by the experiment.
        int(
            cfg.get(
                "batch_size",
                64
            )
        ),

        # Fixed seed used for deterministic splitting/loading.
        seed,

        # Number of DataLoader worker processes.
        int(
            cfg.get(
                "workers",
                2
            )
        )
    )

    # train_eval_loader provides a deterministic training view.
    # It is retained for reproducibility/extended evaluation.
    # The optimization loop itself uses train_loader.
    _ = train_eval_loader

    # --------------------------------------------------------
    # Build VGG6 model
    # --------------------------------------------------------

    # Read activation function from the configuration.
    activation = cfg.get(
        "activation",
        "relu"
    )

    # Construct VGG6 with the selected activation.
    model = VGG6(
        activation
    )

    # Move model parameters to CPU/GPU.
    model = model.to(
        device
    )

    # --------------------------------------------------------
    # Define classification loss
    # --------------------------------------------------------

    # CIFAR-10 is a ten-class single-label classification task,
    # therefore CrossEntropyLoss is used.
    criterion = nn.CrossEntropyLoss()

    # --------------------------------------------------------
    # Build optimizer
    # --------------------------------------------------------

    optimizer = make_optimizer(

        # Selected optimizer name.
        cfg.get(
            "optimizer",
            "adam"
        ),

        # Parameters that should be updated.
        model.parameters(),

        # Optimizer learning rate.
        float(
            cfg.get(
                "learning_rate",
                0.001
            )
        ),

        # Weight-decay regularization.
        float(
            cfg.get(
                "weight_decay",
                0.0005
            )
        ),

        # Momentum used where supported.
        float(
            cfg.get(
                "momentum",
                0.9
            )
        )
    )

    # ========================================================
    # W&B INITIALIZATION
    # ========================================================

    # Determine whether the current experiment should be logged
    # to Weights & Biases.
    use_wandb = bool(
        cfg.get(
            "use_wandb",
            False
        )
    )

    # Configure W&B only if enabled.
    if use_wandb:

        # Import W&B only when required.
        import wandb

        # A standalone training call may not yet have a W&B run.
        # Sweep execution, however, already creates the run.
        if wandb.run is None:

            wandb.init(
                project=cfg.get(
                    "wandb_project",
                    "vgg6-cifar10"
                ),
                config=cfg
            )

        # Tell W&B that epoch is the x-axis/step metric.
        wandb.define_metric(
            "epoch"
        )

        # Associate all training/validation metrics with epoch.
        for metric in [
            "train/loss",
            "train/accuracy",
            "validation/loss",
            "validation/accuracy",
        ]:

            wandb.define_metric(
                metric,
                step_metric="epoch"
            )

    # ========================================================
    # OUTPUT PATHS
    # ========================================================

    # Determine where the best checkpoint will be stored.
    checkpoint_path = Path(
        cfg.get(
            "checkpoint_path",
            "checkpoints/baseline_best.pt"
        )
    )

    # Determine where epoch-wise metrics will be stored.
    history_path = Path(
        cfg.get(
            "history_path",
            "outputs/baseline_history.csv"
        )
    )

    # Create checkpoint directory if it does not exist.
    checkpoint_path.parent.mkdir(
        parents=True,
        exist_ok=True
    )

    # Create history-output directory if it does not exist.
    history_path.parent.mkdir(
        parents=True,
        exist_ok=True
    )

    # Store one dictionary of metrics per epoch.
    history = []

    # Initialize best validation accuracy below any valid result.
    best_validation_accuracy = -1.0


    # ========================================================
    # EPOCH-WISE TRAINING LOOP
    # ========================================================
    #
    # This is the OUTER training loop.
    #
    # If epochs = 20, this loop executes 20 times.
    #
    # During each epoch:
    # 1. The complete training dataset is processed.
    # 2. Training metrics are calculated.
    # 3. Validation performance is evaluated.
    # 4. Metrics are logged to W&B.
    # 5. The best model checkpoint is updated if necessary.
    # ========================================================

    for epoch in range(
        1,
        int(
            cfg.get(
                "epochs",
                20
            )
        ) + 1
    ):

        # ----------------------------------------------------
        # Switch model to training mode
        # ----------------------------------------------------
        #
        # This is important because BatchNorm behaves
        # differently during training and evaluation.
        #
        # evaluate_loader() switches to model.eval(), so
        # model.train() must be called again every epoch.
        # ----------------------------------------------------

        model.train()

        # ----------------------------------------------------
        # Reset statistics for the new epoch
        # ----------------------------------------------------

        # Sum of per-sample training losses.
        train_loss_sum = 0.0

        # Number of correctly classified training examples.
        train_correct = 0

        # Total number of training examples processed.
        train_count = 0


        # ====================================================
        # MINI-BATCH TRAINING LOOP
        # ====================================================
        #
        # This is the INNER training loop.
        #
        # Each iteration processes one mini-batch from
        # train_loader.
        # ====================================================

        for images, labels in train_loader:

            # ------------------------------------------------
            # Move mini-batch to selected compute device
            # ------------------------------------------------

            images = images.to(
                device,
                non_blocking=True
            )

            labels = labels.to(
                device,
                non_blocking=True
            )

            # ------------------------------------------------
            # Clear old gradients
            # ------------------------------------------------
            #
            # PyTorch accumulates gradients by default,
            # therefore previous gradients must be reset before
            # calculating gradients for the current mini-batch.
            # ------------------------------------------------

            optimizer.zero_grad(
                set_to_none=True
            )

            # ------------------------------------------------
            # Forward propagation
            # ------------------------------------------------
            #
            # Pass the mini-batch through VGG6 and obtain
            # one classification score per CIFAR-10 class.
            # ------------------------------------------------

            logits = model(
                images
            )

            # ------------------------------------------------
            # Calculate training loss
            # ------------------------------------------------

            loss = criterion(
                logits,
                labels
            )

            # ------------------------------------------------
            # Backpropagation
            # ------------------------------------------------
            #
            # Compute gradients of the loss with respect to
            # all trainable model parameters.
            # ------------------------------------------------

            loss.backward()

            # ------------------------------------------------
            # Parameter update
            # ------------------------------------------------
            #
            # Update model parameters using the selected
            # optimizer such as Adam, SGD, RMSprop or Nadam.
            # ------------------------------------------------

            optimizer.step()

            # ------------------------------------------------
            # Accumulate training loss
            # ------------------------------------------------
            #
            # Multiply batch-average loss by batch size so that
            # the epoch loss can later be computed correctly.
            # ------------------------------------------------

            train_loss_sum += (
                loss.item()
                * labels.size(0)
            )

            # ------------------------------------------------
            # Calculate predicted class
            # ------------------------------------------------

            predictions = logits.argmax(
                dim=1
            )

            # ------------------------------------------------
            # Count correct predictions
            # ------------------------------------------------

            train_correct += (
                predictions
                == labels
            ).sum().item()

            # ------------------------------------------------
            # Count samples processed
            # ------------------------------------------------

            train_count += (
                labels.size(0)
            )


        # ====================================================
        # MINI-BATCH LOOP ENDS HERE
        # ====================================================


        # ----------------------------------------------------
        # Calculate training loss for the complete epoch
        # ----------------------------------------------------

        train_loss = (
            train_loss_sum
            / train_count
        )

        # ----------------------------------------------------
        # Calculate top-1 training accuracy for the epoch
        # ----------------------------------------------------

        train_accuracy = (
            100.0
            * train_correct
            / train_count
        )


        # ====================================================
        # VALIDATION
        # ====================================================
        #
        # Validation is performed after every training epoch.
        #
        # evaluate_loader():
        # - calls model.eval()
        # - disables gradient calculation
        # - calculates validation CrossEntropy loss
        # - calculates validation top-1 accuracy
        # ====================================================

        validation_result = evaluate_loader(
            model,
            val_loader,
            criterion,
            device
        )

        # Retrieve validation loss.
        validation_loss = (
            validation_result[
                "loss"
            ]
        )

        # Retrieve validation top-1 accuracy.
        validation_accuracy = (
            validation_result[
                "accuracy"
            ]
        )


        # ====================================================
        # CREATE EPOCH RESULT
        # ====================================================

        epoch_result = {

            # Epoch number.
            "epoch":
                epoch,

            # Training-set loss.
            "train_loss":
                train_loss,

            # Training-set top-1 accuracy.
            "train_accuracy":
                train_accuracy,

            # Validation-set loss.
            "validation_loss":
                validation_loss,

            # Validation-set top-1 accuracy.
            "validation_accuracy":
                validation_accuracy,
        }

        # Store the result for CSV generation.
        history.append(
            epoch_result
        )

        # Print the current epoch result to the console.
        print(
            epoch_result
        )


        # ====================================================
        # W&B METRIC LOGGING
        # ====================================================

        if use_wandb:

            import wandb

            wandb.log({

                # Explicit W&B step.
                "epoch":
                    epoch,

                # Training loss required for Q3(c).
                "train/loss":
                    train_loss,

                # Training accuracy required for Q3(c).
                "train/accuracy":
                    train_accuracy,

                # Validation loss required for Q3(c).
                "validation/loss":
                    validation_loss,

                # Validation accuracy required for Q3(b)/(c).
                "validation/accuracy":
                    validation_accuracy,

                # Current optimizer learning rate.
                "learning_rate":
                    optimizer.param_groups[0][
                        "lr"
                    ],
            })


        # ====================================================
        # BEST-CHECKPOINT SELECTION
        # ====================================================
        #
        # The assignment evaluates model-selection performance
        # using validation accuracy.
        #
        # Only save a checkpoint when validation accuracy
        # improves.
        # ====================================================

        if (
            validation_accuracy
            > best_validation_accuracy
        ):

            # Update the recorded best validation accuracy.
            best_validation_accuracy = (
                validation_accuracy
            )

            # Save the model that produced the highest
            # validation accuracy so far.
            torch.save(
                {
                    # Learned VGG6 parameters.
                    "model_state":
                        model.state_dict(),

                    # Configuration used to reproduce the run.
                    "config":
                        cfg,

                    # Best validation accuracy associated
                    # with this checkpoint.
                    "best_validation_accuracy":
                        best_validation_accuracy,

                    # Epoch that produced the checkpoint.
                    "best_epoch":
                        epoch,
                },
                checkpoint_path
            )

            print(
                f"New best checkpoint saved at "
                f"epoch {epoch}: "
                f"{best_validation_accuracy:.2f}%"
            )


    # ========================================================
    # EPOCH LOOP ENDS HERE
    # ========================================================


    # ========================================================
    # SAVE COMPLETE TRAINING HISTORY
    # ========================================================

    # Convert the list of epoch dictionaries to a DataFrame.
    history_df = pd.DataFrame(
        history
    )

    # Save training and validation metrics to CSV.
    history_df.to_csv(
        history_path,
        index=False
    )

    print(
        "Training history saved to:",
        history_path
    )


    # ========================================================
    # LOAD BEST VALIDATION CHECKPOINT
    # ========================================================
    #
    # Final testing must use the checkpoint selected using
    # validation performance, rather than blindly using the
    # weights from the final epoch.
    # ========================================================

    checkpoint = torch.load(
        checkpoint_path,
        map_location=device
    )

    # Restore best model parameters.
    model.load_state_dict(
        checkpoint[
            "model_state"
        ]
    )


    # ========================================================
    # FINAL TEST EVALUATION
    # ========================================================

    test_result = evaluate_loader(
        model,
        test_loader,
        criterion,
        device
    )

    # Retrieve final test loss.
    final_test_loss = (
        test_result[
            "loss"
        ]
    )

    # Retrieve final test top-1 accuracy.
    final_test_accuracy = (
        test_result[
            "accuracy"
        ]
    )


    # ========================================================
    # PRINT FINAL RESULTS
    # ========================================================

    final_summary = {

        "best_validation_accuracy":
            best_validation_accuracy,

        "best_epoch":
            checkpoint.get(
                "best_epoch"
            ),

        "final_test_loss":
            final_test_loss,

        "final_test_accuracy":
            final_test_accuracy,

        "checkpoint":
            str(
                checkpoint_path
            ),

        "history":
            str(
                history_path
            ),
    }

    print(
        "Final training summary:"
    )

    print(
        final_summary
    )


    # ========================================================
    # SAVE FINAL W&B SUMMARY
    # ========================================================

    if use_wandb:

        import wandb

        # Store final best validation accuracy
        # for W&B sweep ranking.
        wandb.summary[
            "best_validation_accuracy"
        ] = best_validation_accuracy

        # Store the epoch that produced the best checkpoint.
        wandb.summary[
            "best_epoch"
        ] = checkpoint.get(
            "best_epoch"
        )

        # Store final test loss.
        wandb.summary[
            "final_test_loss"
        ] = final_test_loss

        # Store final test accuracy.
        wandb.summary[
            "final_test_accuracy"
        ] = final_test_accuracy

        # Close W&B only when this training function owns
        # the W&B run.
        if finish_wandb:
            wandb.finish()


    # Return complete epoch history for optional programmatic use.
    return history


# ============================================================
# YAML CONFIGURATION LOADER
# ============================================================

def load_config(
    config_path
):
    """
    Load an experiment configuration from a YAML file.
    """

    # Open YAML file for reading.
    with open(
        config_path,
        "r"
    ) as file:

        # Convert YAML contents to a Python dictionary.
        return yaml.safe_load(
            file
        )


# ============================================================
# COMMAND-LINE ENTRY POINT
# ============================================================
#
# Example:
#
# python -m src.train \
#     --config configs/baseline.yaml \
#     --no-wandb
#
# or:
#
# python -m src.train \
#     --config configs/best.yaml
# ============================================================

if __name__ == "__main__":

    # Create command-line parser.
    parser = argparse.ArgumentParser(
        description=(
            "Train VGG6 on CIFAR-10 using "
            "a YAML experiment configuration."
        )
    )

    # Require path to YAML configuration file.
    parser.add_argument(
        "--config",
        required=True,
        help=(
            "Path to YAML configuration file, "
            "for example configs/baseline.yaml."
        )
    )

    # Optional switch to explicitly disable W&B.
    parser.add_argument(
        "--no-wandb",
        action="store_true",
        help=(
            "Disable Weights & Biases logging "
            "even if YAML enables it."
        )
    )

    # Parse supplied command-line arguments.
    args = parser.parse_args()

    # Load YAML experiment configuration.
    configuration = load_config(
        args.config
    )

    # Override YAML W&B setting when --no-wandb is supplied.
    if args.no_wandb:

        configuration[
            "use_wandb"
        ] = False

    # Start training.
    train(
        configuration
    )