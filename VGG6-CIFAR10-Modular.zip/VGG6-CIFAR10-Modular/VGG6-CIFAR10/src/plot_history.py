import argparse
from pathlib import Path
import matplotlib.pyplot as plt
import pandas as pd


def save_plot(df, column, title, ylabel, output):
    plt.figure(figsize=(7, 4.5))
    plt.plot(df["epoch"], df[column], marker="o", linewidth=2)
    plt.xlabel("Epoch")
    plt.ylabel(ylabel)
    plt.title(title)
    plt.grid(True, alpha=0.3)
    plt.tight_layout()
    plt.savefig(output, dpi=220)
    plt.close()


def main(history, output_dir):
    df = pd.read_csv(history)
    out = Path(output_dir)
    out.mkdir(parents=True, exist_ok=True)
    specs = [
        ("train_accuracy", "Training Accuracy", "Accuracy (%)", "training_accuracy.png"),
        ("train_loss", "Training Loss", "Loss", "training_loss.png"),
        ("validation_accuracy", "Validation Accuracy", "Accuracy (%)", "validation_accuracy.png"),
        ("validation_loss", "Validation Loss", "Loss", "validation_loss.png"),
    ]
    for column, title, ylabel, filename in specs:
        save_plot(df, column, title, ylabel, out / filename)


if __name__ == "__main__":
    p = argparse.ArgumentParser()
    p.add_argument("--history", required=True)
    p.add_argument("--output-dir", default="outputs/plots")
    a = p.parse_args()
    main(a.history, a.output_dir)
