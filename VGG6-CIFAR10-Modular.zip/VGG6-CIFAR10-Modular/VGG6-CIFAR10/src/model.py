# Import PyTorch neural-network functionality.
import torch
import torch.nn as nn
import torch.nn.functional as F


def activation_layer(name: str) -> nn.Module:
    """
    Supported activations:
    ReLU, Sigmoid, Tanh, SiLU and GELU.
    """
    # Convert the activation name to lowercase for consistent matching.
    name = name.lower()

    # Map configuration names to PyTorch activation modules.
    activation_map = {
        "relu": lambda: nn.ReLU(inplace=True),
        "sigmoid": nn.Sigmoid,
        "tanh": nn.Tanh,
        "silu": lambda: nn.SiLU(inplace=True),
        "gelu": nn.GELU,
    }

    # Prevent unsupported activation names from silently being used.
    if name not in activation_map:
        raise ValueError(
            f"Unsupported activation: {name}"
        )

    # Construct and return the selected activation layer.
    return activation_map[name]()


def make_layers(
    cfg,
    activation="relu",
    batch_norm=True
):
    """
    Build the convolutional feature extractor from a VGG-style
    configuration list.
    """

    # Store generated network layers.
    layers = []

    # CIFAR-10 images contain three RGB input channels.
    in_channels = 3

    # Process each entry in the VGG configuration.
    for value in cfg:

        # 'M' represents a 2x2 max-pooling operation.
        if value == "M":

            layers.append(
                nn.MaxPool2d(
                    kernel_size=2,
                    stride=2
                )
            )

        else:

            # Create a 3x3 convolution while preserving spatial size.
            conv = nn.Conv2d(
                in_channels,
                value,
                kernel_size=3,
                padding=1
            )

            # Add the convolution to the feature extractor.
            layers.append(conv)

            # Add Batch Normalization when enabled.
            if batch_norm:
                layers.append(
                    nn.BatchNorm2d(value)
                )

            # Add the activation selected by the experiment.
            layers.append(
                activation_layer(
                    activation
                )
            )

            # Output channels become the input channels
            # of the following convolution.
            in_channels = value

    # Combine all feature layers into one sequential module.
    return nn.Sequential(*layers)


class VGG6(nn.Module):
    """
    VGG6 CNN adapted for CIFAR-10 classification.
    """

    def __init__(
        self,
        activation="relu",
        num_classes=10
    ):

        # Initialize the PyTorch parent class.
        super().__init__()

        # Construct the VGG6 feature extractor.
        self.features = make_layers(
            [
                64,
                64,
                "M",
                128,
                128,
                "M"
            ],
            activation,
            True
        )

        # Map the final 128 extracted features to
        # the ten CIFAR-10 classes.
        self.classifier = nn.Linear(
            128,
            num_classes
        )

        # Initialize learnable parameters.
        self._initialize_weights()


    def forward(self, x):
        """
        Define the forward propagation of an input batch.
        """

        # Extract convolutional features.
        x = self.features(x)

        # Convert the feature map to one value per channel.
        x = F.adaptive_avg_pool2d(
            x,
            (1, 1)
        )

        # Flatten the pooled feature tensor.
        x = torch.flatten(
            x,
            1
        )

        # Generate class logits.
        return self.classifier(x)


    def _initialize_weights(self):
        """
        Initialize Conv2d, BatchNorm2d and Linear layers.
        """

        # Visit every layer in the network.
        for module in self.modules():

            # Apply Kaiming initialization to convolutional layers.
            if isinstance(
                module,
                nn.Conv2d
            ):

                nn.init.kaiming_normal_(
                    module.weight,
                    nonlinearity="relu"
                )

                # Initialize convolutional bias to zero when present.
                if module.bias is not None:
                    nn.init.zeros_(
                        module.bias
                    )

            # Initialize BatchNorm scale to one and bias to zero.
            elif isinstance(
                module,
                nn.BatchNorm2d
            ):

                nn.init.ones_(
                    module.weight
                )

                nn.init.zeros_(
                    module.bias
                )

            # Initialize fully connected layers.
            elif isinstance(
                module,
                nn.Linear
            ):

                nn.init.kaiming_normal_(
                    module.weight,
                    nonlinearity="relu"
                )

                if module.bias is not None:
                    nn.init.zeros_(
                        module.bias
                    )