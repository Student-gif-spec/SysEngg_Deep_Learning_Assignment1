# Standard-library module used to seed Python randomness.
import random

# NumPy is required by the Cutout augmentation.
import numpy as np

# Import PyTorch.
import torch

# DataLoader loads batches and Subset selects train/validation indices.
from torch.utils.data import (
    DataLoader,
    Subset
)

# Import CIFAR-10 and image transformations.
from torchvision import (
    datasets,
    transforms
)


# CIFAR-10 channel-wise normalization statistics.
MEAN = (
    0.4914,
    0.4822,
    0.4465
)

STD = (
    0.2023,
    0.1994,
    0.2010
)


class Cutout:
    """
    Mask a square region of an image to provide additional
    data augmentation.
    """

    def __init__(self, length=16):

        # Store the side length of the square region.
        self.length = length


    def __call__(self, img):

        # Obtain image height and width.
        h, w = img.shape[1:]

        # Randomly select the centre of the Cutout region.
        y = np.random.randint(h)
        x = np.random.randint(w)

        # Calculate vertical Cutout boundaries.
        y1 = max(
            0,
            y - self.length // 2
        )

        y2 = min(
            h,
            y + self.length // 2
        )

        # Calculate horizontal Cutout boundaries.
        x1 = max(
            0,
            x - self.length // 2
        )

        x2 = min(
            w,
            x + self.length // 2
        )

        # Clone the image before modification.
        img = img.clone()

        # Mask the selected region.
        img[:, y1:y2, x1:x2] = 0

        return img


def seed_worker(worker_id):
    """
    Seed each DataLoader worker for reproducibility.
    """

    # Obtain a worker-specific deterministic seed.
    worker_seed = (
        torch.initial_seed()
        % (2 ** 32)
    )

    # Seed NumPy.
    np.random.seed(
        worker_seed
    )

    # Seed Python random.
    random.seed(
        worker_seed
    )


def make_loaders(
    data_dir="data",
    batch_size=64,
    seed=42,
    workers=2
):
    """
    Prepare CIFAR-10 training, validation and test DataLoaders.
    """

    # Training transformations include random data augmentation.
    train_transform = transforms.Compose([
        transforms.RandomCrop(
            32,
            padding=4
        ),

        transforms.RandomHorizontalFlip(),

        transforms.ToTensor(),

        transforms.Normalize(
            MEAN,
            STD
        ),

        Cutout(16),
    ])

    # Validation/test data use deterministic transformations only.
    eval_transform = transforms.Compose([
        transforms.ToTensor(),

        transforms.Normalize(
            MEAN,
            STD
        ),
    ])

    # CIFAR-10 training dataset with augmentation enabled.
    train_aug = datasets.CIFAR10(
        data_dir,
        train=True,
        download=True,
        transform=train_transform
    )

    # Second training-dataset view without random augmentation.
    # This lets validation use deterministic preprocessing.
    train_eval = datasets.CIFAR10(
        data_dir,
        train=True,
        download=False,
        transform=eval_transform
    )

    # Official CIFAR-10 test set.
    test_dataset = datasets.CIFAR10(
        data_dir,
        train=False,
        download=True,
        transform=eval_transform
    )

    # Create deterministic train/validation indices.
    generator = (
        torch.Generator()
        .manual_seed(seed)
    )

    indices = torch.randperm(
        len(train_aug),
        generator=generator
    ).tolist()

    # Use 45,000 images for training.
    train_indices = indices[:45000]

    # Use remaining 5,000 training-set images for validation.
    validation_indices = indices[45000:]

    def create_loader(
        dataset,
        indices,
        shuffle,
        loader_seed
    ):
        """Create a deterministic PyTorch DataLoader."""

        # Create a subset when specific indices are supplied.
        selected_dataset = (
            Subset(
                dataset,
                indices
            )
            if indices is not None
            else dataset
        )

        # Create a deterministic generator for this DataLoader.
        loader_generator = (
            torch.Generator()
            .manual_seed(loader_seed)
        )

        return DataLoader(
            selected_dataset,
            batch_size=batch_size,
            shuffle=shuffle,
            num_workers=workers,

            # Pinned memory helps GPU transfer when CUDA is available.
            pin_memory=torch.cuda.is_available(),

            # Ensure DataLoader workers use reproducible random seeds.
            worker_init_fn=seed_worker,

            # Supply deterministic generator.
            generator=loader_generator,

            # Keep worker processes alive between epochs when used.
            persistent_workers=(
                workers > 0
            )
        )

    # Return independent training, evaluation, validation and test loaders.
    return (
        create_loader(
            train_aug,
            train_indices,
            True,
            seed
        ),

        create_loader(
            train_eval,
            train_indices,
            False,
            seed + 1
        ),

        create_loader(
            train_eval,
            validation_indices,
            False,
            seed + 2
        ),

        create_loader(
            test_dataset,
            None,
            False,
            seed + 3
        ),
    )