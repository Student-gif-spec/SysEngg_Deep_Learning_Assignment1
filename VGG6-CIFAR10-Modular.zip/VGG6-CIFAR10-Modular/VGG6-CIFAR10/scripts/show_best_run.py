import argparse
import wandb

if __name__ == "__main__":
    p = argparse.ArgumentParser()
    p.add_argument("--sweep", required=True)
    a = p.parse_args()
    sweep = wandb.Api().sweep(a.sweep)
    finished = [r for r in sweep.runs if r.state == "finished" and r.summary.get("best_validation_accuracy") is not None]
    if not finished:
        raise RuntimeError("No finished runs with best_validation_accuracy found.")
    best = max(finished, key=lambda r: r.summary["best_validation_accuracy"])
    print("Best run:", best.name)
    print("Best validation accuracy:", best.summary["best_validation_accuracy"])
    print("Configuration:")
    for k in ["activation", "optimizer", "learning_rate", "batch_size", "epochs", "weight_decay", "seed"]:
        print(f"  {k}: {best.config.get(k)}")
