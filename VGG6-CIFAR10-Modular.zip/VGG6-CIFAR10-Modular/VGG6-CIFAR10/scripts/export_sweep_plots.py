import argparse
from pathlib import Path
import matplotlib.pyplot as plt
import pandas as pd
from pandas.plotting import parallel_coordinates
import wandb

METRICS = {
    "train/accuracy": "training_accuracy_all_runs.png",
    "train/loss": "training_loss_all_runs.png",
    "validation/accuracy": "validation_accuracy_all_runs.png",
    "validation/loss": "validation_loss_all_runs.png",
}


def main(sweep_path, output_dir):
    out = Path(output_dir)
    out.mkdir(parents=True, exist_ok=True)
    runs = [r for r in wandb.Api().sweep(sweep_path).runs if r.state == "finished"]
    if not runs:
        raise RuntimeError("No finished W&B runs found for this sweep.")

    rows, histories = [], {}
    for run in runs:
        h = run.history(keys=["epoch", *METRICS], pandas=True)
        histories[run.name] = h
        rows.append({
            "run": run.name,
            "activation": run.config.get("activation"),
            "optimizer": run.config.get("optimizer"),
            "learning_rate": run.config.get("learning_rate"),
            "batch_size": run.config.get("batch_size"),
            "epochs": run.config.get("epochs"),
            "validation_accuracy": run.summary.get("best_validation_accuracy"),
        })
    summary = pd.DataFrame(rows)
    summary.to_csv(out / "sweep_summary.csv", index=False)

    for metric, filename in METRICS.items():
        plt.figure(figsize=(9, 5.5))
        for run_name, h in histories.items():
            if metric in h and h[metric].notna().any():
                plt.plot(h["epoch"], h[metric], label=run_name, alpha=0.8)
        plt.xlabel("Epoch"); plt.ylabel(metric); plt.title(metric.replace("/", " ").title())
        plt.grid(True, alpha=0.3); plt.legend(fontsize=7, ncol=2); plt.tight_layout()
        plt.savefig(out / filename, dpi=220); plt.close()

    plt.figure(figsize=(9, 5.5))
    for run_name, h in histories.items():
        if "validation/accuracy" in h and h["validation/accuracy"].notna().any():
            plt.scatter(h["epoch"], h["validation/accuracy"], s=18, alpha=0.65, label=run_name)
    plt.xlabel("Step / Epoch"); plt.ylabel("Validation Accuracy (%)")
    plt.title("Validation Accuracy vs. Step"); plt.grid(True, alpha=0.3)
    plt.legend(fontsize=7, ncol=2); plt.tight_layout()
    plt.savefig(out / "validation_accuracy_vs_step_scatter.png", dpi=220); plt.close()

    p = summary.dropna(subset=["validation_accuracy"]).copy()
    if p.empty:
        raise RuntimeError("Finished runs do not contain best_validation_accuracy.")
    for col in ["activation", "optimizer"]:
        p[col] = pd.Categorical(p[col]).codes
    cols = ["activation", "optimizer", "learning_rate", "batch_size", "epochs", "validation_accuracy"]
    p = p[["run", *cols]].dropna()
    plt.figure(figsize=(12, 6))
    parallel_coordinates(p, "run", cols=cols, alpha=0.7)
    plt.title("Sweep Parallel Coordinates")
    plt.ylabel("Parameter value / encoded category")
    plt.xticks(rotation=20); plt.grid(True, alpha=0.25); plt.tight_layout()
    plt.savefig(out / "parallel_coordinates.png", dpi=220); plt.close()
    print("Saved six plots and sweep_summary.csv to", out)


if __name__ == "__main__":
    p = argparse.ArgumentParser()
    p.add_argument("--sweep", required=True, help="entity/project/sweep_id")
    p.add_argument("--output-dir", default="outputs/sweep_plots")
    a = p.parse_args()
    main(a.sweep, a.output_dir)
