import sys
from pathlib import Path
import wandb

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from src.train import train


def main():
    with wandb.init() as run:
        cfg = dict(wandb.config)
        cfg["use_wandb"] = True
        cfg["checkpoint_path"] = str(ROOT / "checkpoints" / f"sweep_{run.id}.pt")
        cfg["history_path"] = str(ROOT / "outputs" / f"history_{run.id}.csv")
        train(cfg, finish_wandb=False)


if __name__ == "__main__":
    main()
